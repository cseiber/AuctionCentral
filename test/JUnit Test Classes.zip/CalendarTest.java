/**
 * 
 */
package test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author Carl
 *
 */
public class CalendarTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link model.Calendar#Calendar()}.
	 */
	@Test
	public void testCalendar() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link model.Calendar#addAuction(model.Auction)}.
	 */
	@Test
	public void testAddAuction() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link model.Calendar#addAuctionTest()}.
	 */
	@Test
	public void testAddAuctionTest() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link model.Calendar#addItemTest()}.
	 */
	@Test
	public void testAddItemTest() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link model.Calendar#getAuctions(java.util.Date)}.
	 */
	@Test
	public void testGetAuctions() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link model.Calendar#deleteAuction(java.lang.String)}.
	 */
	@Test
	public void testDeleteAuction() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link model.Calendar#hasAuction(java.lang.String)}.
	 */
	@Test
	public void testHasAuction() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link model.Calendar#main(java.lang.String[])}.
	 */
	@Test
	public void testMain() {
		fail("Not yet implemented");
	}

}
