/**
 * 
 */
package test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author Carl
 *
 */
public class UserTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link model.User#User(java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testUser() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link model.User#getMyUserName()}.
	 */
	@Test
	public void testGetMyUserName() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link model.User#setMyUserName(java.lang.String)}.
	 */
	@Test
	public void testSetMyUserName() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link model.User#getMyName()}.
	 */
	@Test
	public void testGetMyName() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link model.User#setMyName(java.lang.String)}.
	 */
	@Test
	public void testSetMyName() {
		fail("Not yet implemented");
	}

}
