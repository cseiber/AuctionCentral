/**
 * 
 */
package test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author Carl
 *
 */
public class AuctionTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link model.Auction#Auction(model.NPO, int)}.
	 */
	@Test
	public void testAuction() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link model.Auction#addItem(model.Item)}.
	 */
	@Test
	public void testAddItem() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link model.Auction#getNPO()}.
	 */
	@Test
	public void testGetNPO() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link model.Auction#getItemList()}.
	 */
	@Test
	public void testGetItemList() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link model.Auction#tostring()}.
	 */
	@Test
	public void testTostring() {
		fail("Not yet implemented");
	}

}
